import { readFile } from 'node:fs/promises';
import { access } from 'node:fs/promises';
import { parse } from 'node:path';

const required = [
  'index.html', 'package.json', 'vite.config.js',
  'public/config/ads.config.json', 'public/config/google-auth.config.json',
  'src/assets/app-icon.svg', 'src/main.js', 'src/styles/tokens.css',
  'src/styles/app.css', 'src-tauri/tauri.conf.json', 'docs/INTEGRATIONS.md',
];
for (const file of required) await access(new URL(`../${file}`, import.meta.url));
const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const ads = JSON.parse(await readFile(new URL('../public/config/ads.config.json', import.meta.url), 'utf8'));
const auth = JSON.parse(await readFile(new URL('../public/config/google-auth.config.json', import.meta.url), 'utf8'));
const tauri = JSON.parse(await readFile(new URL('../src-tauri/tauri.conf.json', import.meta.url), 'utf8'));
if (pkg.scripts?.dev === undefined) throw new Error('Missing Vite dev script');
if (ads.enabled !== false || ads.provider !== 'unselected') throw new Error('Ad provider must remain unselected for this milestone');
if (auth.enabled !== false || auth.clientId !== '' || auth.oauth?.usePkce !== true) throw new Error('Google OAuth must remain disabled and require PKCE');
if (tauri.identifier !== 'com.nexus.adspace') throw new Error('Unexpected Tauri bundle identifier');
console.log(`PASS: ${required.length} required files exist; JSON configs parse; integrations remain safely unconfigured.`);
