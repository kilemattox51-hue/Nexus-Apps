# Integration setup

## Advertising provider

The provider is intentionally unselected. Do not enable `public/config/ads.config.json` until a provider is chosen and its documented SDK or API contract is reviewed.

The current feed adapter accepts a normalized JSON response. The endpoint may return an array directly, or an object containing an `ads` array:

```json
{
  "ads": [
    {
      "id": "campaign-123",
      "format": "image",
      "brand": "Advertiser name",
      "title": "Campaign headline",
      "description": "Campaign description",
      "category": "Technology",
      "mediaUrl": "https://cdn.example.com/banner.webp",
      "posterUrl": "",
      "ctaLabel": "Learn more",
      "clickUrl": "https://advertiser.example.com/landing",
      "disclosure": "Sponsored"
    }
  ]
}
```

Supported `format` values are `image`, `video`, and `text`. Video records use `mediaUrl` for the video file and may use `posterUrl` for the poster frame. All media and click-through URLs must be HTTPS in production. The adapter currently makes a simple GET request to the configured endpoint; many ad networks require their own SDK, auction, impression/click tracking, consent handling, and policy checks. Those must be implemented in a provider-specific adapter after the vendor is selected. A generic feed endpoint is only an integration seam, not a replacement for a vendor SDK.

During development, `enabled` remains `false`, so clearly labelled preview placements fill the card layout. If an enabled feed is empty or unreachable, preview placements are used when `fallback.showPreviewCards` is true. Preview content is not a live ad and should never be reported as an impression.

## Google sign-in / OAuth 2.0

This project is a Tauri desktop app. Create an OAuth client of type **Desktop app** in Google Cloud Console; do not create a Web application client for this desktop build. The starter config uses a loopback redirect on `127.0.0.1` with an ephemeral port and requires PKCE S256 plus a per-request `state` value.

1. Create or select a Google Cloud project.
2. Configure the OAuth consent screen and add the app's authorized test users while testing.
3. Create an OAuth client ID with application type **Desktop app**.
4. Put the client ID in `public/config/google-auth.config.json` as `clientId`.
5. Keep `enabled` set to `false` until the native local callback listener, authorization-code exchange, ID-token validation, and secure token storage are implemented and tested.

Do not add a client secret to the desktop app. A native desktop binary is a public client and cannot keep an embedded secret confidential. Use the system browser, PKCE S256, state validation, exact redirect matching, and OS secure storage for any tokens. Do not store access or refresh tokens in frontend localStorage. Request only `openid`, `email`, and `profile` for basic sign-in; request any additional scopes later and only when a feature needs them.

The current Sign in button is intentionally a setup notice. It does not authenticate users yet. `public/config/google-auth.config.json` is a configuration scaffold, not a completed OAuth implementation.

## Brand palette

The CSS tokens in `src/styles/tokens.css` centralize the initial dark plum, muted violet, lilac, rose, sage, amber, and slate palette. These are working values, not confirmed brand hex codes. Replace the token values when the approved Nexus palette is supplied. The purple atmospheric glow is rendered on the workspace background with a negative stacking layer and cannot cover cards or controls.
