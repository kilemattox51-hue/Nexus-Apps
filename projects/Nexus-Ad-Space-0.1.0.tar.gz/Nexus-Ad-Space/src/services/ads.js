import { previewAds } from '../data/preview-ads.js';

const safeFormat = (value) => ['image', 'video', 'text'].includes(String(value).toLowerCase())
  ? String(value).toLowerCase()
  : 'text';

function normalizeAd(ad, index) {
  return {
    id: String(ad.id ?? `live-ad-${index + 1}`),
    format: safeFormat(ad.format),
    category: String(ad.category ?? 'Other'),
    brand: String(ad.brand ?? 'Advertiser'),
    brandMark: String(ad.brandMark ?? String(ad.brand ?? 'A').slice(0, 1)).slice(0, 2),
    title: String(ad.title ?? 'Sponsored placement'),
    description: String(ad.description ?? ''),
    mediaUrl: typeof ad.mediaUrl === 'string' ? ad.mediaUrl : '',
    posterUrl: typeof ad.posterUrl === 'string' ? ad.posterUrl : '',
    ctaLabel: String(ad.ctaLabel ?? 'Learn more'),
    clickUrl: typeof ad.clickUrl === 'string' ? ad.clickUrl : '',
    disclosure: String(ad.disclosure ?? 'Sponsored'),
    palette: 'violet',
    isPreview: false,
    featured: Boolean(ad.featured),
  };
}

export async function loadAds() {
  let config;
  try {
    const response = await fetch('/config/ads.config.json', { cache: 'no-store' });
    if (!response.ok) throw new Error(`Ad config returned ${response.status}`);
    config = await response.json();
  } catch (error) {
    return { ads: previewAds.map((ad) => ({ ...ad, isPreview: true })), mode: 'preview', detail: error.message };
  }

  if (!config.enabled || config.provider === 'unselected' || !config.endpoint) {
    return { ads: config.fallback?.showPreviewCards === false ? [] : previewAds.map((ad) => ({ ...ad, isPreview: true })), mode: 'preview' };
  }

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), Number(config.requestTimeoutMs) || 8000);
  try {
    const response = await fetch(config.endpoint, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
      mode: 'cors',
    });
    if (!response.ok) throw new Error(`Ad feed returned ${response.status}`);
    const payload = await response.json();
    const source = Array.isArray(payload) ? payload : payload?.[config.expectedResponse?.rootProperty || 'ads'];
    if (!Array.isArray(source)) throw new Error('Ad feed did not contain an ads array');
    const ads = source.map(normalizeAd);
    if (ads.length) return { ads, mode: 'live' };
    return { ads: config.fallback?.showPreviewCards === false ? [] : previewAds.map((ad) => ({ ...ad, isPreview: true })), mode: 'preview', detail: 'The connected feed returned no placements.' };
  } catch (error) {
    return { ads: config.fallback?.showPreviewCards === false ? [] : previewAds.map((ad) => ({ ...ad, isPreview: true })), mode: 'preview', detail: error.name === 'AbortError' ? 'Ad feed timed out.' : error.message };
  } finally {
    window.clearTimeout(timeout);
  }
}
